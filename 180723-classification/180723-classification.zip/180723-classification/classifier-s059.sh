#!/bin/sh

python3 ./src/classification.py $1
