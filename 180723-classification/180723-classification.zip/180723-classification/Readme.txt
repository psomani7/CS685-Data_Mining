Shivam Tulsyan
Roll Number - 180723
Data Mining Endsem

Dependencies - numpy, pandas, scikit-learn, statistics, matplotlib, imbalanced-learn, sys, xgboost
all packages can be installed using pip or should be already installed

1. All input files are kept in the ./Input folder.
2. Makefile can be executed with(it also install all dependencies)
```
make ARGS="path to test file"
```
3. Python script is present in the ./src folder, execute it with
4. Bash script is in top level folder itself, can be executed with
```
bash classifier-s028.sh "path to test file"
```
5. Outputs generated are stored in ./Output folder.
6. The path to the test file should be provided as written in point 2.