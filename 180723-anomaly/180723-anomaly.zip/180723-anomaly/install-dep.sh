#!/bin/bash

pip install numpy
pip install pandas
pip install statistics
pip install matplotlib
pip install xgboost
pip install scikit-learn
pip install imbalanced-learn
