Shivam Tulsyan
Roll Number - 180723
Data Mining Endsem

Dependencies - numpy, pandas, scikit-learn, statistics, matplotlib, imbalanced-learn, sys, xgboost
all packages can be installed using pip or should be already installed

1. All input files are kept in the ./Input folder.
2. Makefile can be executed with(it also install all dependencies)
```
make
```
3. Python script is present in the ./src folder, execute it with
4. Bash script is in top level folder itself, can be executed with
```
bash anomaly-s028.sh "path to test file"
```
5. Outputs generated are stored in ./Output folder.