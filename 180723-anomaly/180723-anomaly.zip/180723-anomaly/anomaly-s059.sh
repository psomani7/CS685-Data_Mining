#!/bin/sh

python3 ./src/anomaly.py
